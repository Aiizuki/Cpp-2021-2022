#include "fonction.hpp"

int main() {
  png::image< png::rgb_pixel > image("input.png");
  image.write("output.png");


  return EXIT_SUCCESS;
}
